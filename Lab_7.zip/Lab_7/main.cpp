#include <string>
#include <map>
#include <iostream>
#include <fstream>
#include <typeinfo>
#include "Node.cpp"
#include "PriorityQueue.cpp"
#include "MorseTable.cpp"
#include "DynamicArray.cpp"

using namespace std;

DynamicArray<string> encrypt;
PriorityQueue<Node> queue;

string walkDecrypt(Node *node, ifstream &stream); 
void walkEncrypt(Node *node, const string &code); 

int main(int argc, char **argv) {

  for(pair<string, string> pair:getMorseTable()) { 
    int code = 0;
    for(char c:pair.second) {
      if(c == '-') {
        code += 0b01;
      } else {
        code += 0b10;
      }
      code <<= 2;
    }
    code >>= 2;
    queue.enqueue(new Leaf(pair.first, code)); 
  }

  Node *root;
  while(true) { 
    Node *first = queue.dequeue();
    Node *second = queue.dequeue();
    if(second == nullptr) {
      root = first;
      break;
    }
    queue.enqueue(new Branch(first, second));
  }

  walkEncrypt(root, ""); 

  ifstream in("raw.txt");
  ofstream out("encrypt.txt");
  bool first = true;
  while(!in.eof()) {
    char c;
    in.get(c);
    if(!first){
      if(c==' '){ 
        out<<"11";
        in.get(c);
      }
      else{
        out<<"00";
      }
    }
    c = (char)toupper((int)c);
    string en = encrypt.get((int)c);
    out<<en;
    first = false;
  }
  out.flush();
  out.close();
  in.close();
  cout << "Encrypted file generated! Check the folder " << endl;

  ifstream ein("encrypt.txt");
  ofstream fout("decrypt.txt");
  while(!ein.eof()){
    string dec = walkDecrypt(root, ein);
    if(ein.eof()) break;
    fout<<dec;
    char s1, s2;
    ein >> s1 >> s2;
    if(s1=='1'){
      fout<<' ';
    }
  }
  ein.close();
  fout.flush();
  fout.close();
  cout << "Decrypted file generated! Check the folder " << endl;
  return 0;
}

void walkEncrypt(Node *node, const string &code) {
  if(typeid(*node) == typeid(Leaf)) {
    auto leaf = (Leaf *) node;
    encrypt.insert((int)(leaf->symbol()[0]), code);
  } else {
    auto branch = (Branch *) node;
    Node *left = branch->left();
    Node *right = branch->right();
    if(left != nullptr) {
      walkEncrypt(left, code + "0");
    }
    if(right != nullptr) {
      walkEncrypt(right, code + "1");
    }
  }
}

string walkDecrypt(Node *node, ifstream &stream) {
  if(typeid(*node) == typeid(Leaf)) {
    return ((Leaf *) node)->symbol();
  } else {
    auto branch = (Branch *) node;
    char next;
    stream >> next;
    if(next == '0') {
      return walkDecrypt(branch->left(), stream);
    } else {
      return walkDecrypt(branch->right(), stream);
    }
  }
}
